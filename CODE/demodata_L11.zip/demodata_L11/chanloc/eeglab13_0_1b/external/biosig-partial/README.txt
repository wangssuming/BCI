This is only part of the BIOSIG package
The full BIOSIG package is available at

http://biosig.sourceforge.net/
