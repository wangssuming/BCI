function [estimate] = ft_inverse_pcc(csd, leadfield, varargin)

% FT_INVERSE_PCC
%
% Use as
%  estimate = ft_inverse_pcc(csd, leadfield, ...)

