function [estimate] = ft_inverse_mne(dat, cov, leadfield, varargin)

% FT_INVERSE_MNE
%
% Use as
%  estimate = ft_inverse_mne(dat, cov, leadfield, ...)

