function [estimate] = ft_inverse_residualvariance(dat, leadfield, varargin)

% FT_INVERSE_RESIDUALVARIANCE
%
% Use as
%  estimate = ft_inverse_residualvariance(dat, leadfield, ...)

