function [estimate] = ft_inverse_music(cov, leadfield, varargin)

% FT_INVERSE_MUSIC
%
% Use as
%  estimate = ft_inverse_music(cov, leadfield, ...)

