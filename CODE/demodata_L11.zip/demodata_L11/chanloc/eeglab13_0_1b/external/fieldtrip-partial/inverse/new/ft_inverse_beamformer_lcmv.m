function [estimate] = ft_inverse_lcmv(cov, leadfield, varargin)

% FT_INVERSE_LCMV
%
% Use as
%  estimate = ft_inverse_lcmv(cov, csd, leadfield, ...)

