function [estimate] = ft_inverse_dipolefit(dat, vol, sens, varargin)

% FT_INVERSE_DIPOLEFIT
%
% Use as
%  estimate = ft_inverse_dipolefit(dat, vol, sens, ...)

