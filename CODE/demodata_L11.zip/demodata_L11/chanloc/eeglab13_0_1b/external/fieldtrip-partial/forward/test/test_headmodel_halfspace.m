function test_headmodel_halfspace

% FIXME why is this test script empty?
