function test_ft_prepare_vol_sens

% FIXME why is this test script empty?
