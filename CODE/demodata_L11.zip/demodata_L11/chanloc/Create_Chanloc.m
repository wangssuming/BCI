%% Author: Lu, Chia-Feng 2013.12.11
clear, close all
clc

%% initialize parameters
%%% please set the Matlab path first !!
%%% or use "pathtool"

%% edit the information of channel locations using EEGlab GUI
Chanloc=pop_chanedit('');  
% run channel editer GUI
% [Method 1]
% step 1: Press "Insert chan" for several times till the Channel number is enough
% step 2: Make sure the check box of "Channel in data array" for each channel is selected 
% step 3: Type the Channel label for each channel according to the standard EEG labeling, such as FP1, C3, Pz.
% step 4: Press "Look up locs" button and press "..." button to select the "Standard-10-20-Cap81.ced" file
% step 5: [optional] press "Plot 2-D" or "Plot 3-D" buttons to check the channel locations
% step 6: press "Ok" button to output the channel locations as the variable "Chanloc"
%
% [Method 2]
% step 1: press the button on the left-lower corner "Read locations"
% step 2: open file "Standard-10-20-Cap81.ced" and select "autodetect" file format
% step 3: delete the unused channels
% step 4: [optional] press "Plot 2-D" or "Plot 3-D" buttons to check the channel locations
% step 5: press "Ok" button to output the channel locations as the variable "Chanloc"

%% save the Chanloc
[filename filepath]=uiputfile('*.mat');
save([filepath filename],'Chanloc')